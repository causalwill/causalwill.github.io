#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define MAX_STUDENTS 200

struct message {
    int year;
    int clas;
    int rank;
};

struct person {
    char num[9];
    char name[20];
    int subject;
    struct message xinxi;
    int flag;
};

const char* subject_names[] = {
    "����", "��ѧ", "����", "��ʷ", "����", "����"
};

int read(struct person p[]) {
    int n = 0;
    FILE *fp = fopen("D:/gao.txt", "r");
    if (fp == NULL) {
        printf("�޷����ļ�: gao.txt!\n");
        exit(1);
    }
    
    while (fscanf(fp, "%8s %19s %d", p[n].num, p[n].name, &p[n].subject) == 3) {
        n++;
        if (n >= MAX_STUDENTS) break;
    }
    
    fclose(fp);
    return n;
}

int str_to_int(char *num, int i, int n) {
    int dig = 0;
    for (; i <= n; i++) {
        dig = dig * 10 + (num[i] - '0');
    }
    return dig;
}

struct message get_message(char *num) {
    struct message xinxi;
    xinxi.year = str_to_int(num, 0, 3);
    xinxi.clas = str_to_int(num, 4, 4);
    xinxi.rank = str_to_int(num, 5, 7);
    return xinxi;
}

int check_choice(struct person *p) {
    int a[3];
    a[0] = p->subject / 100;
    a[1] = (p->subject / 10) % 10;
    a[2] = p->subject % 10;
    
    // ����Ŀ�Ƿ���1-6��Χ���Ҳ��ظ�
    if ((a[0] >= 1 && a[0] <= 6) &&
        (a[1] >= 1 && a[1] <= 6) &&
        (a[2] >= 1 && a[2] <= 6) &&
        (a[0] != a[1]) && (a[1] != a[2]) && (a[0] != a[2])) {
        return 1;
    }
    return 0;
}

int message_cmp(struct message xinxi1, struct message xinxi2) {
    if (xinxi1.year < xinxi2.year) return -1;
    if (xinxi1.year > xinxi2.year) return 1;
    if (xinxi1.clas < xinxi2.clas) return -1;
    if (xinxi1.clas > xinxi2.clas) return 1;
    if (xinxi1.rank < xinxi2.rank) return -1;
    if (xinxi1.rank > xinxi2.rank) return 1;
    return 0;
}

void message_sort(struct person p[], int n) {
    struct person temp;
    int i,j; 
    for (i = 0; i < n - 1; i++) {
        for (j = 0; j < n - i - 1; j++) {
            if (message_cmp(p[j].xinxi, p[j + 1].xinxi) > 0) {
                temp = p[j];
                p[j] = p[j + 1];
                p[j + 1] = temp;
            }
        }
    }
}

void change(int sub) {
    int a[3];
    a[0] = sub / 100;
    a[1] = (sub / 10) % 10;
    a[2] = sub % 10;
    int j;
    for (j = 0; j < 3; j++) {
        if (a[j] >= 1 && a[j] <= 6) {
            printf("%s ", subject_names[a[j] - 1]);
        }
    }
}

void get_all_person(struct person p[], int n) {
	int i;
    for (i = 0; i < n; i++) {
        p[i].flag = check_choice(&p[i]);
        p[i].xinxi = get_message(p[i].num);
    }
}

void display_person1(struct person p[], int n, int flag) {
    printf("ѧ��\t����\t������Ŀ\t\t����״̬\n");
    printf("------------------------------------------------\n");
    int i;
    for (i = 0; i < n; i++) {
        if (p[i].flag == flag) {
            printf("%s\t%s\t", p[i].num, p[i].name);
            if (flag == 1) {
                change(p[i].subject);
                printf("\t�����ɹ�\n");
            } else {
                printf("%03d\t\t����ʧ��\n", p[i].subject);
            }
        }
    }
    printf("\n");
}

void display_person2(struct person p[], int n) {
    int count = 0;
    printf("��������ȷ��ͬѧ��Ϣ:\n");
    printf("ѧ��\t����\n");
    printf("----------------\n");
    int i;
    for (i = 0; i < n; i++) {
        if (p[i].flag == 0) {
            printf("%s\t%s\n", p[i].num, p[i].name);
            count++;
        }
    }
    printf("\n��������ȷ��ͬѧ����%d��\n\n", count);
}

void select_person(struct person p[], int n, int subject) {
    printf("����%s��ͬѧ:\n", subject_names[subject - 1]);
    printf("ѧ��\t����\n");
    printf("----------------\n");
    int i;
    for (i = 0; i < n; i++) {
        if (p[i].flag == 1) {
            int sub1 = p[i].subject / 100;
            int sub2 = (p[i].subject / 10) % 10;
            int sub3 = p[i].subject % 10;
            
            if (sub1 == subject || sub2 == subject || sub3 == subject) {
                printf("%s\t%s\n", p[i].num, p[i].name);
            }
        }
    }
    printf("\n");
}

void check_subject_num(struct person p[], int n) {
    int count[6] = {0};
    int i;
    // ͳ�Ƹ���Ŀ��������
    for (i = 0; i < n; i++) {
        if (p[i].flag == 1) {
            int sub1 = p[i].subject / 100;
            int sub2 = (p[i].subject / 10) % 10;
            int sub3 = p[i].subject % 10;
            
            count[sub1 - 1]++;
            if (sub2 != sub1) count[sub2 - 1]++;
            if (sub3 != sub1 && sub3 != sub2) count[sub3 - 1]++;
        }
    }
    
    // �������Ŀ�������
    for (i = 0; i < 6; i++) {
        printf("%s(%d)��������: %d��\n", subject_names[i], i+1, count[i]);
        select_person(p, n, i+1);
    }
}

int check_sub(int sub) {
    int s1 = sub / 100;
    int s2 = (sub / 10) % 10;
    int s3 = sub % 10;
    
    return ((s1 >= 1 && s1 <= 6) &&
            (s2 >= 1 && s2 <= 6) &&
            (s3 >= 1 && s3 <= 6) &&
            (s1 != s2) && (s2 != s3) && (s1 != s3));
}

int num_cmp(struct person p[], int n, char *num1) {
	int i;
    for (i = 0; i < n; i++) {
        if (strcmp(p[i].num, num1) == 0) {
            return i;
        }
    }
    return -1;
}

void revise(struct person p[], int n, int *modified) {
    char num[9];
    int sub, i;
    
    printf("������Ҫ�޸ĵ�ѧ��: ");
    scanf("%8s", num);
    
    i = num_cmp(p, n, num);
    if (i == -1) {
        printf("����: δ�ҵ�ѧ��Ϊ %s ��ѧ��\n\n", num);
        return;
    }
    
    printf("�������µı�����Ŀ(3λ����): ");
    scanf("%d", &sub);
    
    if (!check_sub(sub)) {
        printf("����: ��Ŀ���벻��ȷ\n\n");
        return;
    }
    
    p[i].subject = sub;
    p[i].flag = 1;
    *modified = 1;
    
    printf("\n�޸ĳɹ�:\n");
    printf("ѧ��\t����\t�±�����Ŀ\n");
    printf("----------------------------\n");
    printf("%s\t%s\t", p[i].num, p[i].name);
    change(sub);
    printf("\n\n");
}

void save(struct person p[], int n) {
    FILE *fp = fopen("gao_updated.txt", "w");
    if (fp == NULL) {
        printf("�޷������ļ�: gao_updated.txt!\n");
        return;
    }
    
    message_sort(p, n);
    int i;
    for (i = 0; i < n; i++) {
        fprintf(fp, "%s %s %03d\n", p[i].num, p[i].name, p[i].subject);
    }
    
    fclose(fp);
    printf("�����ѳɹ����浽 gao_updated.txt\n\n");
}

void display_menu() {
    printf("\n�Ϻ��и��еȼ���Ԥ������Ϣ����ϵͳ\n");
    printf("================================\n");
    printf("1. ��ʾ���б�����Ϣ\n");
    printf("2. ��ʾ����������Ϣ\n");
    printf("3. �ֿ�Ŀ��ѯ������Ϣ\n");
    printf("4. �޸ı�����Ϣ\n");
    printf("0. �˳�����\n");
    printf("================================\n");
    printf("��ѡ�����(0-4): ");
}

int main() {
    struct person p[MAX_STUDENTS];
    int n = read(p);
    int modified = 0;
    int choice;
    
    get_all_person(p, n);
    message_sort(p, n);
    
    do {
        display_menu();
        scanf("%d", &choice);
        
        switch (choice) {
            case 1:
                printf("\n����ѧ��������Ϣ:\n");
                display_person1(p, n, 1);
                display_person1(p, n, 0);
                break;
                
            case 2:
                printf("\n����������Ϣ:\n");
                display_person2(p, n);
                break;
                
            case 3:
                printf("\n�ֿ�Ŀ�������:\n");
                check_subject_num(p, n);
                break;
                
            case 4:
                revise(p, n, &modified);
                break;
                
            case 0:
                if (modified) {
                    save(p, n);
                }
                printf("�������˳�\n");
                break;
                
            default:
                printf("��Чѡ������������!\n");
        }
    } while (choice != 0);
    
    return 0;
}
